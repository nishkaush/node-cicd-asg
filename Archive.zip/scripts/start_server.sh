
source /home/ec2-user/.bash_profile
cd /home/ec2-user/my-app/
pm2 start index.js --name nishant-server