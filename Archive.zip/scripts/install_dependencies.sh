
source /home/ec2-user/.bash_profile
cd /home/ec2-user/my-app/
npm install pm2@latest -g
npm install 
